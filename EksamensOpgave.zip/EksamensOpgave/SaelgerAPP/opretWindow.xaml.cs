﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DatabaseAuction;
namespace SaelgerAPP
{
    /// <summary>
    /// Interaction logic for opretWindow.xaml
    /// </summary>
    public partial class opretWindow : Window
    {
        private CsharpEksamenOpgabeEntities db = new CsharpEksamenOpgabeEntities();
        private int saelgerId;
        public opretWindow(int saelgerId)
        {
            InitializeComponent();
            this.saelgerId = saelgerId;
            initializeMetals();
        }

        private void initializeMetals()
        {
            string[] metals = { "Guld", "Sølv", "Platin", "Palladium" };

            MetalTyper.ItemsSource = metals;
        }

        private void opret_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                
                Salgsudbud salgsudbud = new Salgsudbud();
                string date = Date.Text.Trim() + " ";
                date += Klokkeslet.Text.Trim();
                salgsudbud.deadline = DateTime.Parse(date);

                salgsudbud.gram = Decimal.Parse(Mængde.Text.Trim());
                salgsudbud.MetalType = MetalTyper.SelectedItem.ToString();
                salgsudbud.saelger_Id = saelgerId;
                db.Salgsudbud.Add(salgsudbud);
                db.SaveChanges();
                
            }
            catch
            {
                MessageBox.Show("ups noget gik galt");
            }
            finally
            {
                this.Close();
            }
        }

        private void Annuller_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
