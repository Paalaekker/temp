﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DatabaseAuction;

namespace SaelgerAPP
{
    /// <summary>
    /// Interaction logic for SalgsudbudOverviewWindow.xaml
    /// </summary>
    public partial class SalgsudbudOverviewWindow : Window
    {
        private ObservableCollection<Koebstilbud> koebstilbud = new ObservableCollection<Koebstilbud>();
        private bool runThreads = true;
        private int salgsudbudID;
        private CsharpEksamenOpgabeEntities db = new CsharpEksamenOpgabeEntities();
        public SalgsudbudOverviewWindow(int salgsudbudID)
        {
            InitializeComponent();
            this.salgsudbudID = salgsudbudID;
            StartThreads();
            DataContext = koebstilbud;
            
        }

        private void StartThreads()
        {
            Thread t = new Thread(new ThreadStart(addKoebsTilbud));
            t.Start();
        }
        

        private void addKoebsTilbud()
        {
            while (runThreads)
            {
               
                db.Koebstilbud.ToList().Where(k => k.salgsudbud_Id == salgsudbudID).ToList().ForEach(k => {
                    if (!koebstilbud.ToList().Exists(tmp=> tmp.k_Id == k.k_Id))
                        this.Dispatcher.Invoke(() => koebstilbud.Add(k));

                });

                Thread.Sleep(5000);
              
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            runThreads = false;
        }

        private void CloseOverview(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
