﻿using DatabaseAuction;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Windows;

namespace SaelgerAPP
{
    /// <summary>
    /// Interaction logic for SalgsudbudWIndow.xaml
    /// </summary>

    public partial class SalgsudbudWIndow : Window
    {
        CsharpEksamenOpgabeEntities db = new CsharpEksamenOpgabeEntities();
        ObservableCollection<Salgsudbud> salgsudbud = new ObservableCollection<Salgsudbud>();
        private Saelger saelger;
        //private Collection<Thread> threads = new Collection<Thread>();
        private bool runThreads = true;
        public SalgsudbudWIndow(Saelger saelger)
        {
            InitializeComponent();
            

            DataContext = salgsudbud;
            this.saelger = saelger;
            startUpdateThread();
        }
  
        public void updateSalgsudbud()
        {
            try
            {

                while (runThreads)
                {
                  
                    
                    this.db.Salgsudbud.ToList().ForEach(s => { 
                        if(s.Saelger.s_Id == saelger.s_Id)
                            {
                        if (!this.salgsudbud.ToList().Exists(item => item.s_Id == s.s_Id))
                            this.Dispatcher.Invoke(() => salgsudbud.Add(s));
                            else
                            {
                                this.Dispatcher.Invoke(() =>
                                {

                                    try
                                    {
                                        db = new CsharpEksamenOpgabeEntities();
                   
                                        Salgsudbud tmp = salgsudbud.Single(salg => salg.s_Id == s.s_Id); 
                                       
                                        if (tmp.Koebstilbud.Count < s.Koebstilbud.Count)
                                        {
                                            tmp.Koebstilbud = s.Koebstilbud;
                                            tmp.hoejstePris = s.hoejstePris;
                                        }
                                        
                                   
                                    }
                                    catch
                                    {
                                        MessageBox.Show("købstilbud ikke opdateret");
                                    }
                                });
                            }
                        }
                        
                    });

                    Thread.Sleep(5000);
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
        
        }
        public void updateClock()
        {
            try
            {

                while (runThreads)
                {

                    salgsudbud.ToList().ForEach(s => s.Time = "");
                    

                    Thread.Sleep(1000);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

        }
        private void startUpdateThread()
        {
            Thread s = new Thread(new ThreadStart(updateSalgsudbud));
            s.Start();
     
            Thread t = new Thread(new ThreadStart(updateClock));
            t.Start();
         
        
        }

        private void nytSalgsudbud_Click(object sender, RoutedEventArgs e)
        {
            opretWindow opretWindow = new opretWindow(saelger.s_Id);
            opretWindow.Show();
          
            

        }
        private void LogOut(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
        private void Exit(object sender, RoutedEventArgs e)
        {
            
            MessageBoxButton buttons = MessageBoxButton.YesNo;
            
           var result = MessageBox.Show("Er du sikker?","Log ud",buttons);
            if (result.ToString().Equals("Yes"))
            {
                this.Close();
            }
          

        }
        private void closeALLThreads()
        {
            runThreads = false;        
        }

        private void SalgsudbudList_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            Salgsudbud tmp = (Salgsudbud)SalgsudbudList.SelectedItem;
            SalgsudbudOverviewWindow salgsudbudOverviewWindow = new SalgsudbudOverviewWindow(tmp.s_Id);
            salgsudbudOverviewWindow.Show();
        }

        private void Window_Closed(object sender, System.ComponentModel.CancelEventArgs e)
        {
            closeALLThreads();
        }
    }


       
        
}
