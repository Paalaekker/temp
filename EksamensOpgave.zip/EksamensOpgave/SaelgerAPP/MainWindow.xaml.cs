﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DatabaseAuction;

namespace SaelgerAPP
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        CsharpEksamenOpgabeEntities db = new CsharpEksamenOpgabeEntities();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Saelger saelger = db.Saelger.ToList().Single(s => s.email == EmailSearch.Text.Trim() && s.password == password.Text.Trim());
                SalgsudbudWIndow salgsudbudWIndow = new SalgsudbudWIndow(saelger);
                salgsudbudWIndow.Show();
                this.Close();

            }
            catch
            {
                MessageBox.Show("hovsa du har ikke indtastet email og kode rigtigt");
                EmailSearch.Clear();
                password.Clear();
                Login.IsEnabled = false;
            }
        }

        private void checkText(object sender, TextChangedEventArgs e)
        {
            if (password.Text.Length > 0 && EmailSearch.Text.Length > 0)
                Login.IsEnabled = true;
        }
    }
}
