﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DatabaseAuction;

namespace KoeberWEBB
{
    public class KoebstilbudsController : Controller
    {
        private CsharpEksamenOpgabeEntities db = new CsharpEksamenOpgabeEntities();

    

     

        // GET: Koebstilbuds/Create
        public ActionResult Create()
        {
          
            return View();
        }

        // POST: Koebstilbuds/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "pris")] Koebstilbud koebstilbud, int id)
        {
            if (ModelState.IsValid)
            {
                
                koebstilbud.email = (string)Session["email"];
                int kId = (int)Session["kId"];
                koebstilbud.koeber_Id = kId;
                koebstilbud.navn = (string)Session["name"];
                koebstilbud.tlf = (string)Session["tlf"];
                koebstilbud.salgsudbud_Id = id;
                Salgsudbud salgsudbud;
                try
                {
                     salgsudbud = db.Salgsudbud.Single(s => s.s_Id == koebstilbud.salgsudbud_Id);
                }
                catch
                {
                    return RedirectToAction("KoebsError", "Koebstilbuds");
                }
                if (salgsudbud!=null && salgsudbud.hoejstePris < koebstilbud.pris)
                {
                    if (salgsudbud.deadline <= DateTime.Now)
                        return RedirectToAction("Outdated", "koebstilbuds");
                    db.Koebstilbud.Add(koebstilbud);
                    db.SaveChanges();
                    return RedirectToAction("Details", "Koeber", new { id = kId });
                }
                else
                {

                    return RedirectToAction("KoebsError", "Koebstilbuds");
                }


                
            }

            ViewBag.koeber_Id = new SelectList(db.Koeber, "id", "navn", koebstilbud.koeber_Id);
            ViewBag.salgsudbud_Id = new SelectList(db.Salgsudbud, "s_Id", "MetalType", koebstilbud.salgsudbud_Id);
            return View(koebstilbud);
        }

   

        public ActionResult KoebsError()
        {
            return View();
        }
        public ActionResult Outdated()
        {
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
