﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DatabaseAuction;

namespace KoeberWEBB
{
    public class KoeberController : Controller
    {
        private CsharpEksamenOpgabeEntities db = new CsharpEksamenOpgabeEntities();

    
        public struct KoeberInfo
        {
            public string email { get; set; }
            public string password { get; set; }

        }

        [HttpPost]
        public ActionResult Login(KoeberInfo k)
        {

            foreach (var item in db.Koeber.ToList())
            {
                if (item.email == k.email && item.p_Password == k.password)
                {
                    Session.Add("name", item.navn);
                    Session.Add("tlf", item.tlf);
                    Session.Add("email", item.email);
                    Session.Add("kId", item.id);
                    return RedirectToAction("Details", "Koeber", new { id = item.id }); 
                }


            }

            return RedirectToAction("Error", "Shared");
        }
        public ActionResult Login()
        {
            Session.Clear();
            return View(new KoeberInfo());
        }
        // GET: Koeber/Details/
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Koeber koeber = db.Koeber.Find(id);
            if (koeber == null)
            {
                return HttpNotFound();
            }
            return View(koeber);
        }

        // GET: Koeber/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Koeber/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "navn,email,tlf,p_Password")] Koeber koeber)
        {


            if (ModelState.IsValid)
            {
                
                db.Koeber.Add(koeber);
                db.SaveChanges();
                return RedirectToAction("LogIn");
            }

            return View(koeber);
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
