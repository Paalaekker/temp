﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DatabaseAuction;

namespace KoeberWEBB
{
    public class SalgsudbudsController : Controller
    {
        private CsharpEksamenOpgabeEntities db = new CsharpEksamenOpgabeEntities();

        // GET: Salgsudbuds
        public ActionResult Index()
        {
            var salgsudbud = db.Salgsudbud.Include(s => s.Saelger);
            return View(salgsudbud.ToList());
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
